package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

import com.mansourappdevelopment.androidapp.kidsafe.models.Call;

public interface OnCallDeleteClickListener {
    //no longer used because we used the swiping instead of clicking the delete button
    //void onCallDeleteClick(Call call);

}
