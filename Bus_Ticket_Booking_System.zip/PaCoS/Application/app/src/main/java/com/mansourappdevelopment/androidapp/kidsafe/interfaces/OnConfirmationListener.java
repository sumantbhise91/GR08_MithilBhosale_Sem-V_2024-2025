package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

public interface OnConfirmationListener {
    void onConfirm();

    void onConfirmationCancel();
}
