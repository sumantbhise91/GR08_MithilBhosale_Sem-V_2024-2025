package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

import com.mansourappdevelopment.androidapp.kidsafe.models.Message;

public interface OnMessageDeleteClickListener {
    //used swiping instead of a button
    //void onMessageDeleteClick(Message message);
}
