package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

public interface OnGoogleChildSignUp {

    void onModeSelected(String parentEmail);
}
