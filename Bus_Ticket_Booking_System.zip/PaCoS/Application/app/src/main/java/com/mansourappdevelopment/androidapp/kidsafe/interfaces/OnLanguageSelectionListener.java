package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

public interface OnLanguageSelectionListener {
	void onLanguageSelection(String language);
}
