package com.mansourappdevelopment.androidapp.kidsafe.models;

public class Parent extends User {
	public Parent() {
	}
	
	public Parent(String name, String email) {
		super(name, email);
	}
}
