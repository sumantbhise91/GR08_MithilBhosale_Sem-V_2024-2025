package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

public interface OnFragmentChangeListener {
    void onFragmentChange(int id);
}
