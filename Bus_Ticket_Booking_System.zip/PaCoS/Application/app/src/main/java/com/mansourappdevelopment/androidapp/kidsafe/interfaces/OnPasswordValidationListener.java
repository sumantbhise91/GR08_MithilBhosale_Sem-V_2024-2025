package com.mansourappdevelopment.androidapp.kidsafe.interfaces;

public interface OnPasswordValidationListener {
	void onValidationOk();
}
