package com.harshRajpurohit.we_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
